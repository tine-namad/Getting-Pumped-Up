package Plane;

public class Vehicle {

	String speed = "805";
	String color = "Blue-Black";
	String price = "120,000,000";
		

		 void stop() {
			System.out.println("The plane is landing! (Override the stop method.)");
		}
}
