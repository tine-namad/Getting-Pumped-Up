package Plane;

	public class Plane_Test {
		public static void main(String[] args) {

		U2_Spy_Plane flying = new U2_Spy_Plane();
		
		flying.fly();
		flying.stop();
		
		System.out.println("\nU-2 SPY PLANE SPECIFICATIONS:");
        System.out.println("Name: " + flying.name);
        System.out.println("Price: P" + flying.price);
        System.out.println("Speed: " + flying.speed + " km/h");
        System.out.println("Wingspan: " + flying.wingspan);
        System.out.println("Color: " + flying.color);
		

	}
}
