package Plane;

	public class U2_Spy_Plane extends Vehicle{

	String name = "Lockheed U-2";
	String wingspan = "104ft 10in";
	 
	@Override
	void stop() {
	//super.stop();//
	System.out.println("Lockheed U-2 is now landing!");	        
	}
	 
	void fly() {
		 System.out.println("U-2 Spy Plane is now flying!");

	}
}
