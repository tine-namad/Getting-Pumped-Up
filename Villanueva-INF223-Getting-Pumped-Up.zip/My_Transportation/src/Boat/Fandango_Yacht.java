package Boat;

public class Fandango_Yacht extends Vehicle {
	String boatName = "Fandango Yacht";
	String mainSail_color = "White";
	 
	 
	@Override
	void stop() {
		 //super.stop();//
		 System.out.println("The Fandango Yacht is now anchoring.");        
	    }
	 
	void Float() {
		 System.out.println("Fandango Yacht is now floating.");
	

	}
}


