package Boat;

public class Vehicle {

		String speed = "24";
		String color = "White";
		String price = "$28,000,000";

			 void stop() {
				System.out.println("The boat stopped! (Override the stop method.)");
			}
	}

