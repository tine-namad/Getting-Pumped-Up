package Boat;

public class Boat_Test {
	public static void main(String[] args) {

		Fandango_Yacht floating = new Fandango_Yacht();
	
		floating.Float();
		floating.stop();
		
        System.out.println("\nFANDANGO YACHT SPECIFICATIONS:");
        System.out.println("Name: " + floating.boatName);
        System.out.println("Price: P" + floating.price);
        System.out.println("Speed: " + floating.speed + " kn");
        System.out.println("Color: " + floating.color);
        System.out.println("Main Sail Color: " + floating.mainSail_color);
        
	}
}
