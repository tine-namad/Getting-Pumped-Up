package Car;

public class Vehicle {

	String speed = "180";
	String color = "Black";
	String price = "1,005,000";
	

	 void stop() {
		System.out.println("Vehicle has stopped! (Override the stop method.)");
	}
}

