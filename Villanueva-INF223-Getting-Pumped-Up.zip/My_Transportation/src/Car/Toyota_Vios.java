package Car;

public class Toyota_Vios extends Vehicle{

	 String name = "Toyota Vios";
	 String tireType = "195/50 R16 Alloy";
	 
	 
	 @Override
	 public void stop() {
		 //super.stop();//
		 System.out.println("Toyota Vios has stopped.");
	    }
	 
	 public void drive() {
		 System.out.println("Toyota Vios is now driving.");
		 
	 }
}
