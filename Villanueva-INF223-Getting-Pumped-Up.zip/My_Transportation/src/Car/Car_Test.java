package Car;

public class Car_Test {
	public static void main(String[] args) {

		Toyota_Vios driving = new Toyota_Vios();
		
		driving.drive();
		driving.stop();
		
		System.out.println("\nTOYOTA VIOS SPECIFICATIONS:");
        System.out.println("Name: " + driving.name);
        System.out.println("Price: P" + driving.price);
        System.out.println("Speed: " + driving.speed + " km/h");
        System.out.println("Color: " + driving.color);
        System.out.println("Tire Type: " + driving.tireType);
        
	}
}
